import xgenValidator.EmailValidator;
/**
 * @Author: Ram Chandra Bhakar
 * @Date: 13 Feb 2018
 * @version: 1.0
 * @Discription Email validator is used to validate all the email address that is supporting following rfc
 * RFC5321,RFC5321,RFC5321,RFC5322,RFC5321,RFC5322,RFC5322,RFC5322,RFC5322,RFC5322,RFC5322,RFC5322,RFC5321,RFC1035
 * Ram Chandra Bhakar
 * Data infosys ltd
 */

public class TestEmail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmailValidator el = new EmailValidator();
		if(el.isValid("भाकर@डाटामेल.भारत"))
			System.out.println("True");
	}
	
}
