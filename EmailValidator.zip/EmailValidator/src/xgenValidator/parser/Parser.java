package xgenValidator.parser;

import xgenValidator.lexer.EmailLexer;
import xgenValidator.lexer.TokenInterface;
import xgenValidator.lexer.Tokens;
import xgenValidator.parser.exception.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/*
 * Author: Ram Chandra Bhakar
 * Date: 13 Feb 2018
 * 
 */
abstract class Parser {
    protected List<Warnings> warnings = new ArrayList<Warnings>();
    protected EmailLexer lexer;
    protected int openedParenthesis = 0;

    public Parser(EmailLexer lexer) {
        this.lexer = lexer;
    }

    public abstract void parse(String part) throws InvalidEmail;

    public List<Warnings> getWarnings() {
        return this.warnings;
    }

    protected void validateQuotedPair() {
        //only applies for emails like "\"@domain.com or "test\"@domain.com
        this.warnings.add(Warnings.DEPRECATED_QP);
    }

    protected boolean escaped() {
        return this.lexer.getPrevious().equals(Tokens.BACKSLASH) && !this.lexer.getCurrent().equals(Tokens.get("GENERIC"));
    }

    protected int getOpenedParenthesis() {
        return this.openedParenthesis;
    }

    protected void parseComment() throws InvalidEmail {
        this.openedParenthesis = 1;
        this.checkUnclosedComment();
        this.warnings.add(Warnings.COMMENT);

        while (!this.lexer.getCurrent().equals(Tokens.CLOSEPARENTHESIS)) {
            if (this.lexer.isNextToken(Tokens.OPENPARETHESIS)) {
                this.openedParenthesis++;
            }
            this.lexer.next();
        }

        if (this.lexer.isNextToken(Tokens.get("GENERIC"))) {
            throw new ATEXTAfterComment("");
        }

        if (this.lexer.isNextToken(Tokens.AT)) {
            this.warnings.add(Warnings.DEPRECATED_CFWS_NEAR_AT);
        }
    }

    protected void checkUnclosedComment() throws InvalidEmail {
        if (!this.lexer.find(Tokens.CLOSEPARENTHESIS)) {
            throw new UnclosedComment("Unclosed Comment");
        }
    }

    protected void checkConsecutiveDots() throws InvalidEmail {
        if (this.lexer.getCurrent().equals(Tokens.DOT) && this.lexer.isNextToken(Tokens.DOT)) {
            throw new ConsecutiveDots("Consecutive dots");
        }
    }


    protected boolean checkDoubleQuote(boolean hasClosingQuote) throws InvalidEmail {
        if (!this.lexer.getCurrent().equals(Tokens.DQUOTE)) {
            return hasClosingQuote;
        }

        if (hasClosingQuote) {
            return hasClosingQuote;
        }

        if (this.lexer.isNextToken(Tokens.get("GENERIC")) && this.lexer.getPrevious().equals(Tokens.get("GENERIC"))) {
            //TODO review this condition.
        }

        this.warnings.add(Warnings.RFC5321_QUOTEDSTRING);
        hasClosingQuote = this.lexer.find(Tokens.DQUOTE);
        if (!hasClosingQuote) {
            throw new UnclosedDQUOTE("Unclosed DQUOTE");
        }
        return hasClosingQuote;
    }

    protected boolean isFWS() {
        List<TokenInterface> FWSTokens = new ArrayList<TokenInterface>(Arrays.asList(
                Tokens.HTAB,
                Tokens.SP,
                Tokens.CR,
                Tokens.LF,
                Tokens.CRLF
        ));

        return !this.escaped() && FWSTokens.contains(this.lexer.getCurrent());
    }

    protected void parseFWS() throws InvalidEmail {
        this.checkCRLFInFWS();
        if (this.lexer.getCurrent().equals(Tokens.CR)) {
            throw new CRWithoutLF("Found CR but no LF");
        }

        if (this.lexer.isNextToken(Tokens.get("GENERIC")) && !this.lexer.getPrevious().equals(Tokens.AT)) {
            throw new ATEXTAfterCFWS("ATEXT found after CFWS");
        }

        if (this.lexer.getCurrent().equals(Tokens.LF) || this.lexer.getCurrent().equals(Tokens.NUL)) {
            throw new ExpectedCTEXT("Expecting CTEXT");
        }

        if (this.lexer.isNextToken(Tokens.AT) || this.lexer.getPrevious().equals(Tokens.AT)) {
            this.warnings.add(Warnings.DEPRECATED_CFWS_NEAR_AT);
        } else {
            this.warnings.add(Warnings.CFWS_FWS);
        }
    }

    private void checkCRLFInFWS() throws InvalidEmail {
        if (!this.lexer.getCurrent().equals(Tokens.CRLF)) {
            return;
        }

        if (this.lexer.getCurrent().equals(Tokens.CRLF)) {
            if (this.lexer.isNextToken(Tokens.CRLF)) {
                throw new ConsecutiveCRLF("Consecutive CRLF");
            }
        }
        if (!this.lexer.isNextToken(new ArrayList<>(Arrays.asList(Tokens.SP, Tokens.HTAB)))) {
            throw new CRLFAtEnd("CRLF at the end");
        }
    }
}
