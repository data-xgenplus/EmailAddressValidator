package xgenValidator.parser.exception;

public class NoLocalPart extends InvalidEmail{

    public NoLocalPart(String message) {
        super(message);
    }
}
