package xgenValidator.parser.exception;

public class ATEXTAfterCFWS extends InvalidEmail {
    public ATEXTAfterCFWS(String message) {
        super(message);
    }
}
