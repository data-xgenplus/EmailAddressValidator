package xgenValidator.parser.exception;

public class ExpectedATEXT extends InvalidEmail {
    public ExpectedATEXT(String message) {
        super(message);
    }
}
