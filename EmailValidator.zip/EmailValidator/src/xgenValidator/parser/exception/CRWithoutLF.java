package xgenValidator.parser.exception;

public class CRWithoutLF extends InvalidEmail {
    public CRWithoutLF(String message) {
        super(message);
    }
}
