package xgenValidator.parser.exception;

public class DomainHyphen extends InvalidEmail {
    public DomainHyphen(String message) {
        super(message);
    }
}
