package xgenValidator.parser.exception;

public class InvalidCharacters extends InvalidEmail {
    public InvalidCharacters(String message) {
        super(message);
    }
}
