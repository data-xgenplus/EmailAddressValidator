package xgenValidator.parser.exception;

public class DotAtStart extends InvalidEmail{
    public DotAtStart(String message) {
        super(message);
    }
}
