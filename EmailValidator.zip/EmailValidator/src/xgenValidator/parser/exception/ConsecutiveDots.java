package xgenValidator.parser.exception;

public class ConsecutiveDots extends InvalidEmail {
    public ConsecutiveDots(String message) {
        super(message);
    }
}
