package xgenValidator.parser.exception;

public class ExpectedDTEXT extends InvalidEmail {
    public ExpectedDTEXT(String message) {
        super(message);
    }
}
