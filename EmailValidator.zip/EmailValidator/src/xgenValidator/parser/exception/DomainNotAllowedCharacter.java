package xgenValidator.parser.exception;

public class DomainNotAllowedCharacter extends InvalidEmail {
    public DomainNotAllowedCharacter(String message) {
        super(message);
    }
}
