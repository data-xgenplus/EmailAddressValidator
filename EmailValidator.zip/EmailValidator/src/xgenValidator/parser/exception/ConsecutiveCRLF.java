package xgenValidator.parser.exception;

public class ConsecutiveCRLF extends InvalidEmail {
    public ConsecutiveCRLF(String message) {
        super(message);
    }
}
