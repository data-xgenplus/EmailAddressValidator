package xgenValidator.parser.exception;

public class ConsecutiveAT extends InvalidEmail {
    public ConsecutiveAT(String message) {
        super(message);
    }
}
