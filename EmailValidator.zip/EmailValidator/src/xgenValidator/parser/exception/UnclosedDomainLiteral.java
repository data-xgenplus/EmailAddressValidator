package xgenValidator.parser.exception;

public class UnclosedDomainLiteral extends InvalidEmail {
    public UnclosedDomainLiteral(String message) {
        super(message);
    }
}
