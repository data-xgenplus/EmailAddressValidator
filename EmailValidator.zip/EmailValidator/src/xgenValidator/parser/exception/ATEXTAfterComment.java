package xgenValidator.parser.exception;

public class ATEXTAfterComment extends InvalidEmail {
    public ATEXTAfterComment(String message) {
        super(message);
    }
}
