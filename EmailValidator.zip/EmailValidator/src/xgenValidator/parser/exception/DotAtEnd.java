package xgenValidator.parser.exception;

public class DotAtEnd extends InvalidEmail {
    public DotAtEnd(String message) {
        super(message);
    }
}
