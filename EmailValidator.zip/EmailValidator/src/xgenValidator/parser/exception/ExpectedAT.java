package xgenValidator.parser.exception;

public class ExpectedAT extends InvalidEmail {
    public ExpectedAT(String message) {
        super(message);
    }
}
