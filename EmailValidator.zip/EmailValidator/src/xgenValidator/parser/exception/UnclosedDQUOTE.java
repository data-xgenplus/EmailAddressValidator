package xgenValidator.parser.exception;

public class UnclosedDQUOTE extends InvalidEmail{
    public UnclosedDQUOTE(String message) {
        super(message);
    }
}
