package xgenValidator.parser.exception;

public class ExpectedCTEXT extends InvalidEmail {
    public ExpectedCTEXT(String message) {
        super(message);
    }
}
