package xgenValidator.parser.exception;

public class CRLFAtEnd extends InvalidEmail {
    public CRLFAtEnd(String message) {
        super(message);
    }
}
