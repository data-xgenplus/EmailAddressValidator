package xgenValidator.parser.exception;

public class UnclosedComment extends InvalidEmail {
    public UnclosedComment(String message) {
        super(message);
    }
}
