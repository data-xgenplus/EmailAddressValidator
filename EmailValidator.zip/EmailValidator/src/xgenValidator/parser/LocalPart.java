package xgenValidator.parser;

import xgenValidator.lexer.EmailLexer;
import xgenValidator.lexer.Token;
import xgenValidator.lexer.TokenInterface;
import xgenValidator.lexer.Tokens;
import xgenValidator.parser.exception.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/*
 * Author: Ram Chandra Bhakar
 * Date: 13 Feb 2018
 * 
 */
final class LocalPart extends Parser {
    private boolean closingQuote = false;
    private boolean parseDQuote = true;
    private static int RFC5321_LOCALPART_MAX_LENGTH = 64;

    LocalPart (EmailLexer lexer) {
        super(lexer);
    }

    @Override
    public void parse(String localpart) throws InvalidEmail {
        lexer.lex(localpart);
        int localPartOpenedParenthesis = 0;
        if (this.lexer.getCurrent().equals(Tokens.DOT)) {
            throw new DotAtStart("Found DOT at start");
        }

        while (!this.lexer.getCurrent().equals(Tokens.AT)) {
            closingQuote = this.checkDoubleQuote(closingQuote);
            if (closingQuote && parseDQuote) {
                this.lexer.next();
                parseDQuote = this.parseDoubleQuote();
            }

            if (this.lexer.getCurrent().equals(Tokens.OPENPARETHESIS)) {
                this.parseComment();
                localPartOpenedParenthesis += getOpenedParenthesis();
            }

            if (this.lexer.getCurrent().equals(Tokens.CLOSEPARENTHESIS)) {
                if(localPartOpenedParenthesis == 0) {
                    throw new UnclosedComment("Missing closing parenthesis");
                }
                localPartOpenedParenthesis--;
            }

            this.checkConsecutiveDots();
            this.checkForInvalidToken(closingQuote);

            if (this.isFWS()) {
                this.parseFWS();
            }

            if (this.lexer.getPrevious().equals(Tokens.BACKSLASH)) {
                if (!this.escaped()) {
                    throw new ExpectedATEXT("Found BACKSLASH");
                }
            }

            lexer.next();
        }

        if (this.lexer.getPrevious().equals(Tokens.DOT)) {
            throw new DotAtEnd("Dot at the end of localpart");
        }

        this.checkRFC5321Length();
    }

    private void checkRFC5321Length() {
        if (this.lexer.lexedText().length() > RFC5321_LOCALPART_MAX_LENGTH) {
            this.warnings.add(Warnings.RFC5321_LOCALPART_TOO_LONG);
        }
    }

    private void checkForInvalidToken(boolean closingQuote) throws InvalidEmail {
        List<TokenInterface> forbidden = new ArrayList<TokenInterface>(Arrays.asList(
                Tokens.COMMA,
                Tokens.CLOSEBRACKET,
                Tokens.OPENBRACKET,
                Tokens.GREATERTHAN,
                Tokens.LOWERTHAN,
                Tokens.COLON,
                Tokens.SEMICOLON
        ));

        if (forbidden.contains(this.lexer.getCurrent()) && !closingQuote) {
            throw new ExpectedATEXT(String.format("Found %s, expeted ATEXT", this.lexer.getCurrent().getName()));
        }
    }

    private boolean parseDoubleQuote() throws InvalidEmail {
        boolean parseAgain = true;
        boolean setSpecialsWarning = true;

        List<TokenInterface> invalid =
                new ArrayList<TokenInterface>(Arrays.asList(Tokens.CR, Tokens.HTAB, Tokens.LF, Tokens.NUL));
        List<TokenInterface> special =
                new ArrayList<TokenInterface>(Arrays.asList(Tokens.CR, Tokens.HTAB, Tokens.LF));

        while (!this.lexer.getCurrent().equals(Tokens.DQUOTE) && !this.lexer.isAtEnd()) {
            parseAgain = false;

            if (special.contains(this.lexer.getCurrent()) && setSpecialsWarning) {
                this.warnings.add(Warnings.CFWS_FWS);
                setSpecialsWarning = false;
            }

            if (!this.escaped() && invalid.contains(this.lexer.getCurrent())) {
                throw new ExpectedATEXT("Invalid token without escaping");
            }

            this.lexer.next();
        }

        if (this.lexer.getPrevious().equals(Tokens.BACKSLASH)) {
           this.checkDoubleQuote(false);
        } else if (!this.lexer.isNextToken(Tokens.AT)) {
            throw new ExpectedAT("Expected AT after quoted part");
        }

        return parseAgain;
    }
}
