package xgenValidator;

import xgenValidator.lexer.EmailLexer;
import xgenValidator.parser.Email;
import xgenValidator.parser.exception.InvalidEmail;

import java.util.Collections;
import java.util.List;
/**
 * @Author: Ram Chandra Bhakar
 * @Date: 13 Feb 2018
 * @version: 1.0
 * @Discription Email validator is used to validate all the email address that is supporting following rfc
 * RFC5321,RFC5321,RFC5321,RFC5322,RFC5321,RFC5322,RFC5322,RFC5322,RFC5322,RFC5322,RFC5322,RFC5322,RFC5321,RFC1035
 * Ram Chandra Bhakar
 * Data infosys ltd
 */


public final class EmailValidator {

	private final Email parser = new Email(new EmailLexer());
    private List<ValidationStrategy> validators = Collections.emptyList();

    public EmailValidator (List<ValidationStrategy> validators) {
        this.validators = validators;
    }

    public EmailValidator () {}

    public boolean isValid(String email) {
        boolean parserResult = true;
        try {
            this.parser.parse(email);
        } catch (InvalidEmail invalidEmail) {
            parserResult = false;
        }

        return parserResult && this.applyValidators(email);
    }

    private boolean applyValidators(String email) {
        boolean validatorsResult = true;
        for (ValidationStrategy validator : this.validators) {
            validatorsResult = validatorsResult && validator.isValid(email, this.parser);
        }

        return validatorsResult;
    }

    public boolean hasWarnings() {
        return !this.parser.getWarnings().isEmpty();
    }

    public List getWarnings() {
        return this.parser.getWarnings();
    }
}
