package xgenValidator.validator;

import xgenValidator.ValidationStrategy;
import xgenValidator.parser.Email;
/*
 * Author: Ram Chandra Bhakar
 * Date: 13 Feb 2018
 * 
 */
public class WarningsNotAllowed implements ValidationStrategy {
    @Override
    public Boolean isValid(String email, Email parser) {
        return parser.getWarnings().size() == 0;
    }
}
