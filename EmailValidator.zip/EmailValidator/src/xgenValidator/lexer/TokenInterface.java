package xgenValidator.lexer;
/*
 * Author: Ram Chandra Bhakar
 * Date: 13 Feb 2018
 * 
 */
public interface TokenInterface {
    String getName();
    String getText();
}
