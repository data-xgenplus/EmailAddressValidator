package xgenValidator.lexer.exception;
/*
 * Author: Ram Chandra Bhakar
 * Date: 13 Feb 2018
 * 
 */
public class TokenNotFound extends RuntimeException {
}
