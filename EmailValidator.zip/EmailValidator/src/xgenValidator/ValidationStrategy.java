package xgenValidator;

import xgenValidator.parser.Email;

/*
 * Author: Ram Chandra Bhakar
 * Date: 13 Feb 2018
 * 
 */
public interface ValidationStrategy {
    Boolean isValid(String email, Email parser);
}
